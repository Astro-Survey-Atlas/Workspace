# NVSS

NVSS 1.4 GHz 图像网格覆盖。

# Legacy Surveys

Legacy Surveys DR10 彩色成像覆盖，不代表 DESI 光谱覆盖。

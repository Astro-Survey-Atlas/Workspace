# KiDS

KiDS DR5 gri 彩色成像覆盖。

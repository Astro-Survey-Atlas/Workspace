# 2MASS

2MASS All-Sky J 波段图像覆盖。

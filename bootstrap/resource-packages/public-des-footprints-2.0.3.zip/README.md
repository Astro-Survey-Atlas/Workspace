# DES

Dark Energy Survey DR2 彩色成像覆盖。

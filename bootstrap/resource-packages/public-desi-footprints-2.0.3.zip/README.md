# DESI Spectroscopy

DESI EDR and DR1 observed spectroscopic tile coverage derived from the official Fuji and Iron TILE_COMPLETENESS tables; this is separate from Legacy Surveys imaging.

# 公开成像巡天覆盖

Euclid、Legacy Surveys、SDSS、HSC-SSP 与 HST 的公开覆盖范围，用于 3D 天球底图。

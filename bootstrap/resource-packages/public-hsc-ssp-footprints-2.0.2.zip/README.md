# HSC-SSP

HSC-SSP PDR2 Wide 与 Deep 的彩色及 grizy 图像 MOC 并集。

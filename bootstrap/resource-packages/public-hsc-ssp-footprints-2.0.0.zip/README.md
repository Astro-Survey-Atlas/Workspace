# HSC-SSP

HSC-SSP PDR2 Wide 与 Deep 彩色成像覆盖并集。

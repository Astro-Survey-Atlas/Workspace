# Pan-STARRS1

Pan-STARRS1 DR1 i/r/g 叠加彩色成像覆盖。

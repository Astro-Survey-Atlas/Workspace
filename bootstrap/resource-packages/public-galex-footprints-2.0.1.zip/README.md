# GALEX

GALEX GR6/GR7 紫外彩色 HiPS 的公开覆盖。
